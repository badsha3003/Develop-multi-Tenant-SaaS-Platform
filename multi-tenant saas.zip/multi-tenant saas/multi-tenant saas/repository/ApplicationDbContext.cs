﻿using Microsoft.EntityFrameworkCore;
using multi_tenant_saas.Models;

namespace multi_tenant_saas.Data
{
    public class ApplicationDbContext:DbContext
    {
        public DbSet<Tenant> Tenants { get; set; }
        public DbSet<User> Users { get; set; }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
    }
}
