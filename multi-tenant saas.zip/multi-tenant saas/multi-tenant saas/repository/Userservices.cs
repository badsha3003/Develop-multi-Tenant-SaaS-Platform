﻿using Microsoft.EntityFrameworkCore;
using multi_tenant_saas.Data;
using multi_tenant_saas.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace multi_tenant_saas.repository
{
    public class Userservices:IUserServices
    {
         ApplicationDbContext _context;

        public Userservices(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<User> RegisterUserAsync(int tenantId, User user)
        {
            var tenant = await _context.Tenants.FindAsync(tenantId);
            if (tenant == null)
                throw new KeyNotFoundException("Tenant not found");

            user.TenantId = tenantId;
            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            return user;
        }

        public async Task<User> GetUserAsync(int tenantId, int userId)
        {
            return await _context.Users
                .Where(u => u.TenantId == tenantId && u.UserId == userId)
                .FirstOrDefaultAsync();
        }

        public async Task<bool> DeleteUserAsync(int tenantId, int userId)
        {
            var user = await _context.Users
                .Where(u => u.TenantId == tenantId && u.UserId == userId)
                .FirstOrDefaultAsync();

            if (user == null) return false;

            _context.Users.Remove(user);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
