﻿using multi_tenant_saas.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace multi_tenant_saas.Data
{
    public interface ITenantServices
    {
        Task<Tenant> RegisterTenantAsync(Tenant tenant);
        Task<Tenant> UpdateTenantAsync(int tenantId, Tenant tenant);
        Task<bool> DeactivateTenantAsync(int tenantId);
    }

   
   
}
