﻿using multi_tenant_saas.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace multi_tenant_saas.Data
{
    public class TeanentService:ITenantServices
    {
        ApplicationDbContext _context;

        public TeanentService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<Tenant> RegisterTenantAsync(Tenant tenant)
        {
            _context.Tenants.Add(tenant);
            await _context.SaveChangesAsync();
            return tenant;
        }

        public async Task<Tenant> UpdateTenantAsync(int tenantId, Tenant tenant)
        {
            var existingTenant = await _context.Tenants.FindAsync(tenantId);
            if (existingTenant == null)
                throw new KeyNotFoundException("Tenant not found");

            existingTenant.Name = tenant.Name;
            existingTenant.ConnectionString = tenant.ConnectionString;
            existingTenant.IsActive = tenant.IsActive;
            await _context.SaveChangesAsync();

            return existingTenant;
        }

        public async Task<bool> DeactivateTenantAsync(int tenantId)
        {
            var tenant = await _context.Tenants.FindAsync(tenantId);
            if (tenant == null) return false;

            tenant.IsActive = false;
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
