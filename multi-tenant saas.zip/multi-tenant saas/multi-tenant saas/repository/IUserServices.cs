﻿using multi_tenant_saas.Data;
using multi_tenant_saas.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace multi_tenant_saas.repository
{
    public interface IUserServices
    {
        Task<User> RegisterUserAsync(int tenantId, User user);
        Task<User> GetUserAsync(int tenantId, int userId);
        Task<bool> DeleteUserAsync(int tenantId, int userId);
    }

  
}
