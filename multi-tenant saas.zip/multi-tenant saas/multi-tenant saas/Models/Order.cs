﻿namespace multi_tenant_saas.Models
{
    public class Order
    {
    }
}
