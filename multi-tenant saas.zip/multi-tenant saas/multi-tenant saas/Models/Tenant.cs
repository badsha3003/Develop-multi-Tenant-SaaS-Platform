﻿using System.ComponentModel.DataAnnotations;

namespace multi_tenant_saas.Models
{
    public class Tenant
    {
        [Key]
        public int TenantId { get; set; }
        public string Name { get; set; }
        public string ConnectionString { get; set; }
        public bool IsActive { get; set; }
    }
}
