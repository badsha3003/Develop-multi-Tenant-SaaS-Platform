﻿using System.ComponentModel.DataAnnotations;

namespace multi_tenant_saas.Models
{
    public class User
    {
        [Key]
        public int UserId { get; set; }
        public int TenantId { get; set; }  // Foreign Key for Tenant
        public string Username { get; set; }
        public string PasswordHash { get; set; }
        public string Role { get; set; }  // Example roles: Admin, User, etc.
        public Tenant Tenant { get; set; }
    }
}
