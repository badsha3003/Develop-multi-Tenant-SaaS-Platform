﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using multi_tenant_saas.Data;
using multi_tenant_saas.Models;
using System.Threading.Tasks;

namespace multi_tenant_saas.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TenantController : ControllerBase
    {
        ITenantServices _tenantService;

        public TenantController(ITenantServices tenantService)
        {
            _tenantService = tenantService;
        }

        [HttpPost]
        public async Task<IActionResult> RegisterTenant([FromBody] Tenant tenant)
        {
            var registeredTenant = await _tenantService.RegisterTenantAsync(tenant);
            return CreatedAtAction(nameof(RegisterTenant), new { id = registeredTenant.TenantId }, registeredTenant);
        }

        [HttpPut("{tenantId}")]
        public async Task<IActionResult> UpdateTenant(int tenantId, [FromBody] Tenant tenant)
        {
            var updatedTenant = await _tenantService.UpdateTenantAsync(tenantId, tenant);
            return Ok(updatedTenant);
        }

        [HttpDelete("{tenantId}")]
        public async Task<IActionResult> DeactivateTenant(int tenantId)
        {
            var result = await _tenantService.DeactivateTenantAsync(tenantId);
            if (!result) return NotFound();
            return NoContent();
        }
    }
}
