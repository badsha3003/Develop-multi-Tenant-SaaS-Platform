﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using multi_tenant_saas.Models;
using multi_tenant_saas.repository;
using System.Threading.Tasks;

namespace multi_tenant_saas.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
       IUserServices _userService;

        public UserController(IUserServices userService)
        {
            _userService = userService;
        }

        [HttpPost("{tenantId}")]
        public async Task<IActionResult> RegisterUser(int tenantId, [FromBody] User user)
        {
            var registeredUser = await _userService.RegisterUserAsync(tenantId, user);
            return CreatedAtAction(nameof(RegisterUser), new { id = registeredUser.UserId }, registeredUser);
        }

        [HttpGet("{tenantId}/{userId}")]
        public async Task<IActionResult> GetUser(int tenantId, int userId)
        {
            var user = await _userService.GetUserAsync(tenantId, userId);
            if (user == null) return NotFound();
            return Ok(user);
        }

        [HttpDelete("{tenantId}/{userId}")]
        public async Task<IActionResult> DeleteUser(int tenantId, int userId)
        {
            var result = await _userService.DeleteUserAsync(tenantId, userId);
            if (!result) return NotFound();
            return NoContent();
        }
    }
}
